from ..packages.crud.base import BaseCrudView
from .tables import BookTable
from .forms import BookForm
from .workflow import BookWorkflow

class BookCrudView(BaseCrudView):
    page_title = "Library Inventory"
    add_button_label = "Add New Book"
    table = BookTable
    form = BookForm
    workflow = BookWorkflow

    def should_display_add_button(self, request):
        return True
