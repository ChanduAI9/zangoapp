from ..packages.workflow.base.engine import WorkflowBase
from .models import Book

class BookWorkflow(WorkflowBase):
    status_transitions = [
        {
            "name": "checkout",
            "label": "Check Out Book",
            "description": "Marks book as checked out.",
            "from": "available",
            "to": "checked_out",
            "confirm_message": "Confirm checkout?",
        },
        {
            "name": "reserve",
            "label": "Reserve Book",
            "description": "Marks book as reserved.",
            "from": "available",
            "to": "reserved",
            "confirm_message": "Confirm reservation?",
        },
        {
            "name": "return_book",
            "label": "Return Book",
            "description": "Marks book as available.",
            "from": ["checked_out", "reserved"],
            "to": "available",
            "confirm_message": "Confirm return?",
        },
        {
            "name": "report_damage",
            "label": "Mark as Damaged",
            "description": "Marks book as damaged.",
            "from": ["available", "checked_out", "reserved"],
            "to": "damaged",
            "confirm_message": "Confirm damaged status?",
        }
    ]

    def checkout_done(self, request, book_instance, transaction):
        book_instance.status = Book.CHECKED_OUT
        book_instance.save()

    def reserve_done(self, request, book_instance, transaction):
        book_instance.status = Book.RESERVED
        book_instance.save()

    def return_book_done(self, request, book_instance, transaction):
        book_instance.status = Book.AVAILABLE
        book_instance.save()

    def report_damage_done(self, request, book_instance, transaction):
        book_instance.status = Book.DAMAGED
        book_instance.save()

    class Meta:
        statuses = {
            "available": {"color": "#28a745", "label": "Available"},
            "checked_out": {"color": "#dc3545", "label": "Checked Out"},
            "reserved": {"color": "#ffc107", "label": "Reserved"},
            "damaged": {"color": "#6c757d", "label": "Damaged"},
        }
        model = Book
        initial_status = "available"
