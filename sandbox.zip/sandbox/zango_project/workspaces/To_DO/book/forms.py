from ..packages.crud.forms import BaseForm
from ..packages.crud.form_fields import ModelField
from .models import Book

class BookForm(BaseForm):
    title = ModelField(placeholder="Enter Book Title", required=True, required_msg="This field is required.")
    author = ModelField(placeholder="Enter Author Name", required=True, required_msg="Author name is required.")
    genre = ModelField(placeholder="Enter Genre", required=True, required_msg="Genre is required.")
    published_date = ModelField(placeholder="Enter Published Date", required=True, required_msg="Published date is required.")

    class Meta:
        title = "Book Management"
        model = Book
